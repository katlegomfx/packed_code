#packed_code
Is a library created as part of a Explore Data Science Academy project where I was tasked with creating and uploading functions of recursion and sorting

## building this package locally
`python setup.py sdist`

## installing this package from github
`pip install git`

## updating this package from github
`pip install --upgrade git`
